guideline_schema_version(1).
guideline_document('stale', ace_sha256(fixture), ulex(none)).
fixture_fact('stale').
