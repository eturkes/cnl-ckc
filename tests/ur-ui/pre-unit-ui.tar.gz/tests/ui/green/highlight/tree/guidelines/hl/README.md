# Highlight fixture
