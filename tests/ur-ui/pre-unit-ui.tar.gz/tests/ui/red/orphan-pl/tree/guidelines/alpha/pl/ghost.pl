fixture(ghost).
